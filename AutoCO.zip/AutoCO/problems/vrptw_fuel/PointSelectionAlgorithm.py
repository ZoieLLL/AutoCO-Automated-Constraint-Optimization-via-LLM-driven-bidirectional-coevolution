import numpy as np
import random
import math


class Solution:
    def __init__(self, problem_data, problem_params, relaxation_strategy):
        self.problem_data = problem_data
        self.problem_params = problem_params
        self.relaxation_strategy = relaxation_strategy
        self.is_multi_instance = problem_data.get("is_multi_instance", False)
        instance_data = problem_data.get("instance_data")
        instances = problem_data.get("instances", [])

        if self.is_multi_instance or instances:
            self.instances = instances
            if self.instances:
                first_instance = self.instances[0]
                self._extract_instance_info(first_instance)
            else:
                raise ValueError("No instance found in multi-instance dataset")
        elif instance_data is not None:
            if isinstance(instance_data, list):
                self.is_multi_instance = True
                self.instances = instance_data
                if self.instances:
                    first_instance = self.instances[0]
                    self._extract_instance_info(first_instance)
                else:
                    raise ValueError("instance data list is empty")
            else:
                self._extract_instance_info(instance_data)
        else:
            self._extract_direct_info(problem_data)

    def _extract_instance_info(self, instance):
        if isinstance(instance, (tuple, list)) and len(instance) >= 7:
            # Solomon格式: (coordinates, distance_matrix, demands, capacity, service_time, time_windows, max_vehicles)
            coordinates, distance_matrix, demands, capacity, service_time, time_windows, max_vehicles = instance[
                :7]

            self.coordinates = coordinates
            self.distance_matrix = distance_matrix
            self.demands = demands
            self.vehicle_capacity = capacity
            self.service_time = service_time
            self.time_windows = time_windows
            self.max_vehicles = max_vehicles
            self.depot = 0
            self.n_customers = len(demands) - 1

        elif isinstance(instance, dict):
            self.coordinates = instance.get("coordinates", np.array([[0, 0]]))
            self.distance_matrix = instance.get("distance_matrix")
            self.demands = instance.get("demands")
            self.vehicle_capacity = instance.get("vehicle_capacity", 40)
            self.service_time = instance.get("service_time")
            self.time_windows = instance.get("time_windows")
            self.max_vehicles = instance.get("max_vehicles", 10)
            self.depot = instance.get("depot", 0)
            self.n_customers = len(self.demands) - \
                1 if self.demands is not None else 0
        else:
            raise ValueError(
                f"Unsupported instance format: {type(instance)}, expected 7-element tuple or list, actual length: {len(instance) if hasattr(instance, '__len__') else 'N/A'}")

    def _extract_direct_info(self, problem_data):
        self.coordinates = problem_data.get("coordinates", np.array([[0, 0]]))
        self.distance_matrix = problem_data.get("distance_matrix")
        self.demands = problem_data.get("demands")
        self.vehicle_capacity = problem_data.get("vehicle_capacity", 40)
        self.service_time = problem_data.get("service_time")
        self.time_windows = problem_data.get("time_windows")
        self.max_vehicles = problem_data.get("max_vehicles", 10)
        self.depot = problem_data.get("depot", 0)
        self.n_customers = len(self.demands) - \
            1 if self.demands is not None else 0

    # ============ General functional area - Start ============

    def get_relaxation_factor(self, constraint_name, default=1.0):
        if hasattr(self, 'relaxation_strategy') and self.relaxation_strategy:
            for item in self.relaxation_strategy:
                if item.get('constraint') == constraint_name:
                    return item.get('relaxation', default)
        return default

    def calculate_distance(self, point1_idx, point2_idx):
        if self.distance_matrix is not None:
            return self.distance_matrix[point1_idx][point2_idx]
        else:
            p1 = self.coordinates[point1_idx]
            p2 = self.coordinates[point2_idx]
            return np.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

    def tour_cost_eoh_compatible(self, solution):
        cost = 0
        current_time = 0

        for j in range(len(solution) - 1):
            travel_time = self.distance_matrix[int(
                solution[j])][int(solution[j + 1])]
            current_time += travel_time

            if current_time < self.time_windows[solution[j + 1]][0]:
                current_time = self.time_windows[solution[j + 1]][0]

            if max(current_time, self.time_windows[solution[j + 1]][0]) > self.time_windows[solution[j + 1]][1]:
                return float('inf')  # Exceeds time window

            current_time += self.service_time[solution[j + 1]]
            cost += travel_time

            if (solution[j + 1] == 0):
                current_time = 0

        return cost

    def calculate_fuel_consumption(self, route, demands, distance_matrix, fuel_capacity=15.0, base_rate=0.1, load_factor=0.001):
        sub_routes = self._parse_routes(route)

        route_fuels = []
        total_fuel = 0.0
        max_route_fuel = 0.0

        for sub_route in sub_routes:
            if len(sub_route) <= 2:
                route_fuels.append(0.0)
                continue

            route_fuel = 0.0
            current_load = 0.0

            for node in sub_route:
                if node != 0:
                    current_load += demands[node]
            for i in range(len(sub_route) - 1):
                from_node = sub_route[i]
                to_node = sub_route[i + 1]

                distance = distance_matrix[from_node][to_node]
                segment_fuel = base_rate * distance + load_factor * current_load * distance
                route_fuel += segment_fuel
                if to_node != 0:
                    current_load -= demands[to_node]

            route_fuels.append(route_fuel)
            total_fuel += route_fuel
            max_route_fuel = max(max_route_fuel, route_fuel)
        feasible = max_route_fuel <= fuel_capacity

        return {
            'feasible': feasible,
            'total_fuel': total_fuel,
            'max_route_fuel': max_route_fuel,
            'route_fuels': route_fuels
        }

    def evaluate_solution(self, solution):
        route = solution.get('route', [])
        if not route:
            return {
                "objective": float('inf'),
                "feasible": False,
                "violations": ["empty_route"],
                "constraint_violations": 1,
                "has_violations": True,
                "fuel_info": {"feasible": False, "total_fuel": 0, "max_route_fuel": 0}
            }

        objective = self.tour_cost_eoh_compatible(route)
        visited_customers = set([node for node in route if node != 0])
        basic_feasible = (
            len(visited_customers) == self.n_customers and
            route[0] == 0 and
            route[-1] == 0 and
            objective != float('inf')
        )
        sub_routes = self._parse_routes(route)
        fleet_relax = self.get_relaxation_factor("fleet_size_constraint", 1.0)
        vehicle_feasible = len(sub_routes) <= self.max_vehicles * fleet_relax
        capacity_relax = self.get_relaxation_factor("capacity_constraint", 1.0)
        capacity_feasible = True
        for sub_route in sub_routes:
            load = self.calculate_route_load(sub_route)
            if load > self.vehicle_capacity * capacity_relax:
                capacity_feasible = False
                break

        fuel_info = self.calculate_fuel_consumption(
            route, self.demands, self.distance_matrix)
        fuel_relaxation = self.get_relaxation_factor("fuel_constraint", 1.0)
        fuel_feasible = fuel_info['max_route_fuel'] <= 15.0 * fuel_relaxation

        overall_feasible = basic_feasible and vehicle_feasible and capacity_feasible and fuel_feasible
        violations = []
        if not basic_feasible:
            if len(visited_customers) != self.n_customers:
                violations.append("visit_constraint")
            if route[0] != 0 or route[-1] != 0:
                violations.append("route_format")
            if objective == float('inf'):
                violations.append("time_window_constraint")

        if not vehicle_feasible:
            violations.append("fleet_size_constraint")

        if not capacity_feasible:
            violations.append("capacity_constraint")

        if not fuel_feasible:
            violations.append("fuel_constraint")

        return {
            "objective": objective,
            "feasible": overall_feasible,
            "violations": violations,
            "constraint_violations": len(violations),
            "has_violations": not overall_feasible,
            "fuel_info": fuel_info
        }

    def calculate_route_load(self, route):
        total_load = 0
        for node in route:
            if node != self.depot:
                total_load += self.demands[node]
        return total_load

    def _parse_routes(self, route):
        if not route or route[0] != self.depot:
            return []

        sub_routes = []
        current_route = [self.depot]

        for i in range(1, len(route)):
            current_route.append(route[i])
            if route[i] == self.depot:
                sub_routes.append(current_route)
                current_route = [self.depot]

        return sub_routes

    # ============ General functional area - End ============

    # ============ LLM Fill Area - Start ============
    def select_next_point(self,
                          current_drone_id=None,
                          available_points=None,
                          current_position=None,
                          current_load=None,
                          solution=None,
                          violations=None,
                          iteration=None,
                          max_iterations=None,
                          depot=None,
                          demands=None,
                          distance_matrix=None,
                          time_windows=None,
                          vehicle_capacity=None,
                          service_time=None,
                          max_vehicles=None):
        """
        VRPTW solving strategy based on constraint relaxation and gradual tightening.

        Core Approach:
        Unlike traditional evolutionary rule-based LLM code generation, this method uses
        predefined constraint relaxation strategies:
        1. Apply relaxed constraints: Build initial solution using preset relaxation factors
        2. Gradual tightening: Progressively tighten constraints and repair violations
        3. Strict validation: Ensure final solution satisfies all original constraints

        LLM Implementation Tasks:
        - Utilize relaxed constraints for rapid initial solution construction
        - Design customer selection and route building logic
        - Repair solutions that violate strict constraints

        ⚠️ External Library Restrictions:
        Prohibited libraries: sklearn, pandas, matplotlib/seaborn, scipy, networkx, gurobipy/cplex

        Input Data:
        - depot: Depot location index (usually 0)
        - demands: Demand array [depot=0, customer1, customer2, ...]
        - distance_matrix: Distance matrix [i][j] = distance from point i to j
        - time_windows: Time windows [[earliest, latest], ...]
        - vehicle_capacity: Maximum vehicle capacity
        - service_time: Service time at each point
        - max_vehicles: Maximum number of vehicles

        Output:
        Complete route: [0, customer1, customer2, ..., 0, customer3, ..., 0]
        (Multiple sub-routes, each starting and ending at depot)
        """
        depot = depot if depot is not None else self.depot
        demands = demands if demands is not None else self.demands
        distance_matrix = distance_matrix if distance_matrix is not None else self.distance_matrix
        time_windows = time_windows if time_windows is not None else self.time_windows
        vehicle_capacity = vehicle_capacity if vehicle_capacity is not None else self.vehicle_capacity
        service_time = service_time if service_time is not None else self.service_time
        max_vehicles = max_vehicles if max_vehicles is not None else self.max_vehicles

        n_customers = len(demands) - 1
        capacity_relaxation = 1.3
        time_window_relaxation = 1.2
        vehicle_count_relaxation = 1.5
        distance_relaxation = 1.1

        relaxed_capacity = vehicle_capacity * capacity_relaxation
        relaxed_max_vehicles = int(max_vehicles * vehicle_count_relaxation)

        unvisited = set(range(1, n_customers + 1))
        route = [depot]
        current_node = depot
        current_load = 0
        current_time = 0
        vehicle_count = 0

        while unvisited and vehicle_count < max_vehicles:
            best_customer = None
            best_distance = float('inf')

            for customer in unvisited:
                if current_load + demands[customer] > vehicle_capacity:
                    continue

                # Basic fuel check
                temp_route = [depot] + [c for c in route[1:] if c != depot] + [customer, depot]
                fuel_info = self.calculate_fuel_consumption(
                    temp_route, demands, distance_matrix, fuel_capacity=15.0)

                if not fuel_info['feasible']:
                    continue
                distance = distance_matrix[current_node][customer]
                if distance < best_distance:
                    best_distance = distance
                    best_customer = customer

            if best_customer is not None:
                route.append(best_customer)
                unvisited.remove(best_customer)
                current_load += demands[best_customer]

                travel_time = distance_matrix[current_node][best_customer]
                current_time += travel_time
                current_time = max(
                    current_time, time_windows[best_customer][0])
                current_time += service_time[best_customer]
                current_node = best_customer
            else:
                # Start new vehicle
                route.append(depot)
                current_node = depot
                current_load = 0
                current_time = 0
                vehicle_count += 1

        # Ensure route ends at depot
        if route[-1] != depot:
            route.append(depot)

        return route

    # ============ LLM Fill Area - End ============

    def solve(self):
        return self.build_solution()

    def build_solution(self):
        if self.is_multi_instance:
            return self._build_multi_instance_solution()
        else:
            return self._build_single_instance_solution()

    def _build_single_instance_solution(self):
        route = self.select_next_point()
        solution = {"route": route}

        evaluation = self.evaluate_solution(solution)

        return {
            "solution": solution,
            "objective": -evaluation["objective"],
            "success": evaluation["feasible"],
            "metrics": evaluation
        }

    def _build_multi_instance_solution(self):
        instance_results = []
        instance_scores = []

        for i, instance in enumerate(self.instances):
            try:
                self._extract_instance_info(instance)
                route = self.select_next_point()
                solution = {"route": route}
                evaluation = self.evaluate_solution(solution)

                instance_results.append({
                    "instance_index": i,
                    "route": route,
                    "objective": evaluation["objective"],
                    "feasible": evaluation["feasible"],
                    "evaluation": evaluation
                })
                if evaluation["feasible"]:
                    instance_scores.append(evaluation["objective"])

            except Exception as e:
                instance_results.append({
                    "instance_index": i,
                    "error": str(e),
                    "feasible": False,
                    "objective": float('inf')
                })
        if instance_scores:
            average_objective = float(np.mean(instance_scores))
            success_rate = len(instance_scores) / len(self.instances)
        else:
            average_objective = float('inf')
            success_rate = 0.0

        return {
            "solution": {
                "average_objective": average_objective,
                "success_rate": success_rate,
                "instance_results": instance_results
            },
            "objective": -average_objective,
            "success": success_rate > 0,
            "metrics": {
                "average_objective": average_objective,
                "success_rate": success_rate,
                "total_instances": len(self.instances),
                "successful_instances": len(instance_scores),
                "multi_instance_evaluation": True
            }
        }
