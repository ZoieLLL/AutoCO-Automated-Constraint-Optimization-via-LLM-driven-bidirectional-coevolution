# Learn to Relax with Large Language Models: Solving Constraint Combinatorial Optimization Problems via Bidirectional Coevolution
 **AutoCO** transforms Large Language Models from passive constraint validators into proactive strategy designers for Constraint Combinatorial Optimization Problems (COPs), achieving breakthrough performance through automated constraint relaxation and bidirectional coevolution.



## 🚀 Features

- **LLM-Driven Strategy Generation**: Automatically generates optimization strategies using large language models
- **Hybrid Algorithm Approach**: Combines MCTS, evolutionary algorithms, and constraint relaxation techniques
- **Multi-Problem Support**: Built-in support for VRPTW, VRPTW with fuel constraints, and multi-drone delivery problems
- **Automated Code Generation**: Generates and evolves solution algorithms automatically
- **Multi-Instance Evaluation**: Supports evaluation across multiple problem instances
- **Repair Mechanism**: Automatically repairs infeasible solutions
- **Comprehensive Logging**: Detailed logging and result tracking

## 📁 Project Structure

```
AutoCO/
├── main.py                    # Main entry point
├── config.json               # Configuration file (create this)
├── problems/                 # Problem definitions
│   ├── vrptw_solomon/       # VRPTW with Solomon instances
│   └── vrptw_fuel/          # VRPTW with fuel constraints
├── Datasets/                # datasets
├── templates/               # Algorithm templates
└── logs/                    # Log files
```

## 🛠️ Installation

1. **Clone the repository**:
```bash
git clone <repository-url>
cd AutoCO
```

2. **Install dependencies**:
```bash
pip install numpy
pip install requests  # for LLM API calls
```

3. **Create configuration file**:
Create a `config.json` file in the root directory:

```json
{
  "llm": {
    "api_key": "your-api-key-here",
    "base_url": "https://api.openai.com/v1",
    "model": "gpt-4",
    "temperature": 0.7,
    "max_tokens": 4000,
    "timeout": 60
  },
  "optimization": {
    "max_outer_iterations": 8,
    "max_inner_iterations": 3,
    "population_size": 3,
    "time_limit": 7200
  }
}
```

## 🚀 Quick Start

### Basic Usage

1. **Run with default VRPTW problem**:
```bash
python main.py --problem_dir problems/vrptw_solomon
```

2. **Run with fuel constraints**:
```bash
python main.py --problem_dir problems/vrptw_fuel
```

### Advanced Usage

1. **Custom parameters**:
```bash
python main.py \
  --problem_dir problems/vrptw_solomon \
  --max_outer_iterations 10 \
  --population_size 5 \
  --time_limit 3600 \
  --output_dir results
```
. **Debug mode**:
```bash
python main.py --problem_dir problems/vrptw_solomon --debug
```

## ⚙️ Configuration Options

### Command Line Arguments

| Argument | Description | Default |
|----------|-------------|---------|
| `--problem_dir` | Problem directory path | None |
| `--max_outer_iterations` | Maximum outer iterations | 8 |
| `--max_inner_iterations` | Maximum inner iterations | 3 |
| `--population_size` | Evolutionary population size | 3 |
| `--time_limit` | Total time limit (seconds) | 72000 |
| `--output_dir` | Output directory | 'output' |
| `--debug` | Enable debug mode | False |
| `--resume` | Resume from checkpoint | False |
| `--disable-repair` | Disable repair mechanism | False |

### Configuration File Options

The `config.json` file supports the following sections:

#### LLM Configuration
```json
{
  "llm": {
    "api_key": "your-api-key",
    "base_url": "https://api.openai.com/v1",
    "model": "gpt-4",
    "temperature": 0.7,
    "max_tokens": 4000,
    "timeout": 60
  }
}

```

## 📈 Output and Results

### Output Structure
```
output/
├── run_20241029_143022/          # Timestamped run directory
│   ├── run_config.json           # Run configuration
│   ├── best_result.json          # Best solution found
│   ├── optimization_log.json     # Detailed optimization log
│   ├── strategies/               # Generated strategies
│   ├── code_variants/            # Generated code variants
│   └── checkpoint.json           # Checkpoint for resume
```

### Result Interpretation

**Objective Values**: 
- Negative values indicate cost minimization (lower is better)
- Positive values indicate profit maximization (higher is better)

**Feasibility**: 
- `feasible: true` indicates all constraints are satisfied
- `violations` array lists any constraint violations

**Metrics**:
- `constraint_violations`: Number of violated constraints
- `objective`: Primary optimization objective
- `success_rate`: Percentage of successfully solved instances

## 🔧 Customization

### Adding New Problems

1. **Create problem directory**:
```bash
mkdir problems/my_problem
```

2. **Create required files**:
   - `problem_data.json`: Problem description
   - `PointSelectionAlgorithm.py`: Base algorithm
   - `instances.json` or `instances.pkl`: Test instances

3. **Define problem constraints** in `problem_data.json`:
```json
{
  "problem_type": "my_problem",
  "description": "My custom optimization problem",
  "constraints": [
    {
      "name": "my_constraint",
      "description": "Description of the constraint",
      "formula": "mathematical_formula"
    }
  ]
}
```

### Customizing Algorithm Templates

Edit `PointSelectionAlgorithm.py` in your problem directory to provide a basic algorithm template that the LLM will improve upon.

## 🐛 Troubleshooting

### Common Issues

1. **"No API key provided"**:
   - Set API key in `config.json` or use `--api_key` argument
   - Check that the config file is in the correct location

2. **"Problem directory does not exist"**:
   - Verify the path to your problem directory
   - Ensure all required files are present

3. **Memory issues with large datasets**:
   - Reduce `population_size` and `max_outer_iterations`
   - Use smaller problem instances for testing

4. **Timeout errors**:
   - Increase timeout values in configuration
   - Check network connectivity for LLM API calls

### Debug Mode

Enable debug mode for detailed logging:
```bash
python main.py --problem_dir problems/vrptw_solomon --debug
```